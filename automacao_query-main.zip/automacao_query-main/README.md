## Automação de execução de query com PostgreSQL e Python.
