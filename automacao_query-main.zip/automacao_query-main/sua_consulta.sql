
SELECT * from sua_tabela(timestamp '2023-05-20 03:00:00', timestamp '2023-08-24 02:59:59',
'', NULL, NULL, NULL, NULL, NULL, '0', '0', '0000, 00000', NULL, NULL, NULL,
'1',0,100000000,'America/Sao_Paulo',NULL,NULL)


